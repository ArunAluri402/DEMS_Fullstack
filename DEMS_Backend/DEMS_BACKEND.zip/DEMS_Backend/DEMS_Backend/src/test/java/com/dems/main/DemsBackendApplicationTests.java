package com.dems.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
